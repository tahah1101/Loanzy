package com.plaid.linksample


import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.plaid.linksample.item_detail.ItemDetail
import com.plaid.linksample.shop.Defaulttems
import com.plaid.linksample.shop.SHOP_ITEM_BUNDLE_KEY
import com.plaid.linksample.shop.ShopItem
import com.plaid.linksample.shop.ShopItemView

/**
 * A simple [Fragment] subclass.
 */
class ShopFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_shop, container, false)
        val recyclerView = view.findViewById<RecyclerView>(R.id.recyclerView)
        recyclerView.adapter = object : RecyclerView.Adapter<ShopItemView>() {
            override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ShopItemView {
                val itemView = LayoutInflater.from(parent.context).inflate(R.layout.show_view, parent, false)
                return ShopItemView(itemView)
            }

            override fun getItemCount(): Int = Defaulttems.SHOP_ITEM.size

            override fun onBindViewHolder(holder: ShopItemView, position: Int) {
                Glide.with(this@ShopFragment).load(Defaulttems.SHOP_ITEM[position].itemUrl).into(holder.itemImage)
                holder.price.text = Defaulttems.SHOP_ITEM[position].itemPrice
                holder.title.text = Defaulttems.SHOP_ITEM[position].itemTitle
                holder.itemView.tag = Defaulttems.SHOP_ITEM[position]
                holder.itemView.setOnClickListener {
                    val startActivity = Intent(context, ItemDetail::class.java)
                    startActivity.putExtra(SHOP_ITEM_BUNDLE_KEY, it.tag as ShopItem)
                    startActivity(startActivity)
                }
            }

        }
        recyclerView.layoutManager = LinearLayoutManager(context, RecyclerView.VERTICAL,false)
        return view
    }


}
