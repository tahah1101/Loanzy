package com.plaid.linksample

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.plaid.link.Plaid
import com.plaid.linkbase.models.*
import com.plaid.linksample.remote.ApiServices
import com.plaid.linksample.util.DelegateExt
import kotlinx.android.synthetic.main.activity_main.*
import okhttp3.ResponseBody
import retrofit2.Call
import java.util.*
import androidx.core.app.ComponentActivity.ExtraData
import androidx.core.content.ContextCompat.getSystemService
import android.icu.lang.UCharacter.GraphemeClusterBreak.T
import com.google.gson.Gson
import com.plaid.linksample.remote.AuthResponse
import org.jetbrains.anko.toast
import org.json.JSONObject
import retrofit2.Callback
import retrofit2.Response


class MainActivity : AppCompatActivity() {

  companion object {
    const val LINK_REQUEST_CODE = 1
  }

  private lateinit var contentTextView: TextView
  var accessToken: String by DelegateExt.stringPreference(this, DelegateExt.ACCESS_TOKEN, DelegateExt.DEFAULT_TOKEN)


  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(R.layout.activity_main)
    setSupportActionBar(toolbar)
    contentTextView = findViewById(R.id.content)

    val linkInitializeOptions = HashMap<String, String>()
    linkInitializeOptions["key"] = "1a439854c7ddd250be682aa394b231"
    linkInitializeOptions["product"] = "auth"
    linkInitializeOptions["apiVersion"] = "v2" // set this to "v1" if using the legacy Plaid API
    linkInitializeOptions["env"] = "sandbox"
    linkInitializeOptions["clientName"] = "Test App"
    linkInitializeOptions["selectAccount"] = "true"
    linkInitializeOptions["webhook"] = "http://requestb.in"
    linkInitializeOptions["baseUrl"] = "https://cdn.plaid.com/link/v2/stable/link.html"

    // Optionally specify email address and legal name for microdeposits. http://plaid.com/docs#auth
    linkInitializeOptions["userEmailAddress"] = "USER_EMAIL_ADDRESS"
    linkInitializeOptions["userLegalName"] = "USER_LEGAL_NAME"

    if (accessToken.equals("")) {
      Plaid.openLink(
        this,
        LinkConfiguration(
          clientName = "Test App",
          products = listOf(PlaidProduct.TRANSACTIONS)
        ),
        LINK_REQUEST_CODE
      )
    }
    else {
      startActivity(Intent(this, HomeActivity::class.java))
    }
  }

  override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
    super.onActivityResult(requestCode, resultCode, intent)
    Log.d("test_111", "onActivityResult")
    if (requestCode == LINK_REQUEST_CODE) {
      when (resultCode) {
        Plaid.RESULT_SUCCESS ->
          (data?.getSerializableExtra(Plaid.LINK_RESULT) as LinkConnection).let {
            val responseStr = getString(
              R.string.content_success,
              it.publicToken,
              it.linkConnectionMetadata.accounts[0].accountId,
              it.linkConnectionMetadata.accounts[0].accountName,
              it.linkConnectionMetadata.institutionId,
              it.linkConnectionMetadata.institutionName
            )
            Log.d("MainActivity", responseStr)
            val apiServices: ApiServices =  ApiServices.RetrofitClient
              .getClient("https://mighty-island-15536.herokuapp.com/")
              .create(ApiServices::class.java)
            val call: Call<AuthResponse> = apiServices.getAccessToken(it.publicToken)
            call.enqueue(object : Callback<AuthResponse> {
              override fun onResponse(call: Call<AuthResponse>, response: Response<AuthResponse>) {

                if(response.code() == 200) {
                  val authResponse = response.body()
                  accessToken = authResponse?.access_token!!
                  startActivity(Intent(this@MainActivity, HomeActivity::class.java))
                }
              }

              override fun onFailure(call: Call<AuthResponse>, t: Throwable) {

              }



            })

          }
        Plaid.RESULT_CANCELLED ->
          (data?.getSerializableExtra(Plaid.LINK_RESULT) as LinkCancellation).let {
            contentTextView.text = getString(
              R.string.content_cancelled,
              it.institutionId,
              it.institutionName,
              it.linkSessionId,
              it.status
            )
          }
        Plaid.RESULT_EXIT ->
          (data?.getSerializableExtra(Plaid.LINK_RESULT) as PlaidApiError).let {
            contentTextView.text = getString(
              R.string.content_exit,
              it.displayMessage,
              it.errorCode,
              it.errorMessage,
              it.linkExitMetadata.institutionId,
              it.linkExitMetadata.institutionName,
              it.linkExitMetadata.status
            )
          }
        Plaid.RESULT_EXCEPTION ->
          (data?.getSerializableExtra(Plaid.LINK_RESULT) as java.lang.Exception).let {
            contentTextView.text = getString(
              R.string.content_exception,
              it.javaClass.toString(),
              it.message
            )
          }
      }
    }
  }

  override fun onCreateOptionsMenu(menu: Menu?): Boolean {
    menuInflater.inflate(R.menu.kotlin_menu, menu)
    return true
  }

  override fun onOptionsItemSelected(item: MenuItem): Boolean =
    when (item.itemId) {

      else -> super.onOptionsItemSelected(item)
    }
}
