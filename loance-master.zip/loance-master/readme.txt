This file contains all of the project required information
