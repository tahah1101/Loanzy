package com.plaid.linksample.remote

data class User(
    val accountId: String = "GaepJovkmyFxzyWrRwDvty6Kr5GWdgu1p5QKl",
    var owed: Int = 65262,
    val name: String = "Plaid Student Loan",
    val subType: String = "Student",
    var paid: Int = 0,
    val type: String = "loan"

)