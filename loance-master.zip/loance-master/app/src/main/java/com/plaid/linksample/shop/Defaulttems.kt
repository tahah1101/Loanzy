package com.plaid.linksample.shop

object Defaulttems {
    val SHOP_ITEM =
        listOf(ShopItem("https://assets.pcmag.com/media/images/608623-iphone-xs-max.jpg?thumb=y",
            "L 999.99", "Iphone XR Max", "At first glance, the iPhone XS vs iPhone XS Max vs iPhone XR comparison doesn't reveal much difference. But after handling and reviewing each, we've developed an in-depth idea of how each is unique in its own way - and suitable for different tastes and needs."),
            ShopItem("https://pisces.bbystatic.com/image2/BestBuy_US/images/products/6202/6202119_sd.jpg",
                "L 1299.99", "Samsung 55 class", "\n" +
                        "Be amazed by stunning lifelike scenes with this 55-inch Samsung smart 4K Ultra HD TV. It supports HDR content for a cinematic viewing experience, and its Ultra HD Engine feature optimizes non-4K images for enhanced visual quality. Connect high-definition media sources to this Samsung smart 4K Ultra HD TV via the two HDMI inputs."),
            ShopItem("https://pisces.bbystatic.com/image2/BestBuy_US/images/products/6290/6290164_sd.jpg",
                "L 699.99", "LG 65 class", "Enjoy your favorite shows and movies with this 65-inch LG 4K UHD smart TV. Its webOS and quad-core processor let you stream content from Netflix and Hulu, download apps and play games. With a slim unibody and Ultra Surround sound, this 65-inch LG 4K UHD smart TV provides a luxurious at-home viewing experience."),
            ShopItem("https://cnet1.cbsistatic.com/img/Kh7VfEtsG2_8OB35ztSn-F4C26g=/868x488/2019/08/08/1342aa94-2973-4054-ad3a-086f7ec17a29/01-lg-b9-oled-tv.jpg",
                "L 1199.99", "LG OLED B9 review", "The LG B9 OLED is a remarkable TV with excellent picture quality that displays perfect blacks. It has excellent wide viewing angles, good SDR peak brightness, and handles reflections well. This TV has a wide color gamut and decent HDR brightness, but the aggressive ABL can become bothersome. Motion looks crisp thanks to the nearly instantaneous response time, and the TV has a motion interpolation feature that can help minimize stutter in movies. Gamers will enjoy a responsive gaming experience thanks to the very low input lag, but unfortunately, just like all OLED TVs, it has the possibility of developing permanent burn-in."))
}