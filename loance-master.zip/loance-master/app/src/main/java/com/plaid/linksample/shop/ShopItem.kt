package com.plaid.linksample.shop

import android.os.Parcel
import android.os.Parcelable

data class ShopItem(val itemUrl: String, val itemPrice: String, val itemTitle: String, val details: String) :
    Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readString()!!,
        parcel.readString()!!,
        parcel.readString()!!,
        parcel.readString()!!
    )

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(itemUrl)
        parcel.writeString(itemPrice)
        parcel.writeString(itemTitle)
        parcel.writeString(details)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<ShopItem> {
        override fun createFromParcel(parcel: Parcel): ShopItem {
            return ShopItem(parcel)
        }

        override fun newArray(size: Int): Array<ShopItem?> {
            return arrayOfNulls(size)
        }
    }
}