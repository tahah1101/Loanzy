package com.plaid.linksample

import android.content.Context
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.content.ContextCompat.getColor
import at.grabner.circleprogress.CircleProgressView
import at.grabner.circleprogress.TextMode
import com.plaid.linksample.remote.User
import kotlinx.android.synthetic.main.fragment_home.view.*

import org.jetbrains.anko.toast


class HomeFragment : Fragment() {

    lateinit var circularProgress: CircleProgressView
    lateinit var pointsTv: TextView
    lateinit var dueTv: TextView
    var points = 0
    var progress = 0.0
    val user = User()

    companion object {
        fun newInstance(): HomeFragment {
            val fragmentHome = HomeFragment()
            val args = Bundle()
            fragmentHome.arguments = args
            return fragmentHome
        }

    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
       val view = inflater.inflate(R.layout.fragment_home, container, false)
        circularProgress = view.findViewById(R.id.circleView)
        pointsTv = view.findViewById(R.id.point_tv)
        dueTv = view.findViewById(R.id.amount_due_tv)
        dueTv.setText(user.owed.toString())

        circularProgress.setMaxValue(100f);
        circularProgress.setValue(0f);
        circularProgress.setValueAnimated(1f);

        circularProgress.setText(user.paid.toString()) //shows the given text in the circle view
        circularProgress.setTextMode(TextMode.TEXT)
        view.payBtn.setBackgroundColor( ContextCompat.getColor(context!!, R.color.lightgrey));
        // Set text mode to text to show text
        view.payBtn.setOnClickListener {

            updateUi(8.34)
            context?.toast("yaay! You paid your dues")
        }
        return view
    }

    private fun updateUi(value: Double) {
        user.paid = user.paid + 5438
        points += 10
        user.owed = user.owed - 5438
        dueTv.setText(user.owed.toString())
        pointsTv.setText(points.toString())
        progress += value
        circularProgress.setText(user.paid.toString())
        circularProgress.setValueAnimated(progress.toFloat())
        if (progress >= 100) {
            circularProgress.setText(0.toString())
            circularProgress.setValue(0f)
            progress = 0.0


        }
    }


}
