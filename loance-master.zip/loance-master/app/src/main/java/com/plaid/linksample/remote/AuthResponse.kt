package com.plaid.linksample.remote

data class AuthResponse(val access_token: String,
                        val item_id: String,
                        val request_id: String)