package com.plaid.linksample.remote

import com.facebook.stetho.okhttp3.StethoInterceptor
import okhttp3.OkHttpClient
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.*

interface ApiServices {

    @Headers("Accept: application/json")
    @FormUrlEncoded
    @POST("get_access_token")
    fun getAccessToken(@Field("public_token") token: String): Call<AuthResponse>

    object RetrofitClient {
        private var retrofit: Retrofit? = null


        fun getClient(baseUrl: String): Retrofit {
            val okHttpClient = OkHttpClient.Builder()
                .addNetworkInterceptor(StethoInterceptor())
                .build()
            if (retrofit == null) {
                retrofit = Retrofit.Builder()
                    .baseUrl(baseUrl)
                    .client(okHttpClient)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build()
            }
            return retrofit!!
        }
    }
}