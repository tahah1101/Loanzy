package com.plaid.linksample


import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import com.google.android.material.button.MaterialButton
import org.jetbrains.anko.find
import android.content.DialogInterface
import android.content.DialogInterface.BUTTON_NEUTRAL
import androidx.appcompat.app.AlertDialog



/**
 * A simple [Fragment] subclass.
 */
class DashboardFragment : Fragment() {
    lateinit var incomeEt: EditText
    lateinit var enterBtn: MaterialButton
    var income: Int = 0
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_dashboard, container, false)
        incomeEt = view.findViewById(R.id.income_et)
        enterBtn = view.find(R.id.enterBtn)

        enterBtn.setOnClickListener {

            income = incomeEt.text.toString().toInt()


            val alertDialog = AlertDialog.Builder(context!!).create()
            alertDialog.setTitle("This is how much you should pay")
            alertDialog.setMessage(calcPayment(income).toString())
            alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                DialogInterface.OnClickListener { dialog, which ->
                    incomeEt.setText("")
                    dialog.dismiss() })
            alertDialog.show()
        }
        return view
    }

    fun calcPayment(income: Int) : Double {
        return (income / 12) * 0.1
    }


}
