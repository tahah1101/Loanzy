package com.plaid.linksample.shop

import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.plaid.linksample.R

class ShopItemView(itemView: View) :
    RecyclerView.ViewHolder(itemView) {
    val itemImage: ImageView = itemView.findViewById(R.id.imageView)
    val price: TextView = itemView.findViewById(R.id.price_view)
    val title: TextView = itemView.findViewById(R.id.item_title)
}