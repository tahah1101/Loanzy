package com.plaid.linksample.shop

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.plaid.linksample.R
import com.plaid.linksample.item_detail.ItemDetail

const val SHOP_ITEM_BUNDLE_KEY = "shop_item_bundle_key"

class ShopListActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val recyclerView = RecyclerView(this)
        recyclerView.adapter = object : RecyclerView.Adapter<ShopItemView>() {
            override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ShopItemView {
                val itemView = LayoutInflater.from(parent.context).inflate(R.layout.show_view, parent, false)
                return ShopItemView(itemView)
            }

            override fun getItemCount(): Int = Defaulttems.SHOP_ITEM.size

            override fun onBindViewHolder(holder: ShopItemView, position: Int) {
                Glide.with(this@ShopListActivity).load(Defaulttems.SHOP_ITEM[position].itemUrl).into(holder.itemImage)
                holder.price.text = Defaulttems.SHOP_ITEM[position].itemPrice
                holder.title.text = Defaulttems.SHOP_ITEM[position].itemTitle
                holder.itemView.tag = Defaulttems.SHOP_ITEM[position]
                holder.itemView.setOnClickListener {
                    val startActivity = Intent(this@ShopListActivity, ItemDetail::class.java)
                    startActivity.putExtra(SHOP_ITEM_BUNDLE_KEY, it.tag as ShopItem)
                    startActivity(startActivity)
                }
            }

        }
        recyclerView.layoutManager = LinearLayoutManager(this,RecyclerView.VERTICAL,false)
        setContentView(recyclerView)
    }
}