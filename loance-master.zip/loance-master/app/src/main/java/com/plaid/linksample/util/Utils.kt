package com.plaid.linksample.util

import android.content.Context
import kotlin.reflect.KProperty

object DelegateExt {

    val ACCESS_TOKEN = "accessToken"
    val DEFAULT_TOKEN = ""
    fun stringPreference(context: Context, name: String, default: String) =
        StringPreference(context, name, default)

    class StringPreference(val context: Context, val name: String, val default: String) {

        val prefs by lazy {
            context.getSharedPreferences("default", Context.MODE_PRIVATE)
        }

        operator fun getValue(thisRef: Any?, property: KProperty<*>): String {
            return prefs.getString(name, default)!!
        }

        operator fun setValue(thisRef: Any?, property: KProperty<*>, value: String) {
            prefs.edit().putString(name, value).apply()
        }

    }
}