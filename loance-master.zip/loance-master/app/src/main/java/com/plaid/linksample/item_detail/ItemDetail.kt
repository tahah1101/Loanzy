package com.plaid.linksample.item_detail

import android.app.Activity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import com.bumptech.glide.Glide
import com.plaid.linksample.R
import com.plaid.linksample.shop.SHOP_ITEM_BUNDLE_KEY
import com.plaid.linksample.shop.ShopItem

class ItemDetail : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.item_details)
        val imageView = intent.extras?.getParcelable<ShopItem>(SHOP_ITEM_BUNDLE_KEY)
        val title: TextView = findViewById(R.id.title)
        val details: TextView = findViewById(R.id.details)
        val button: Button = findViewById(R.id.buy_button)
        title.text = imageView?.itemTitle
        details.text = imageView?.details
        button.text = "Buy " + imageView?.itemPrice
        Glide.with(this@ItemDetail).load(imageView?.itemUrl).into(findViewById(R.id.imageView))
    }

}